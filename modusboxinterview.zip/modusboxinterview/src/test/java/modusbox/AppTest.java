package modusbox;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import modusbox.model.Dog;
import modusbox.model.IChainElement;
import modusbox.model.Point;
import modusbox.model.Tile;
import org.junit.Test;

import java.util.*;

public class AppTest 
{


    @Test
    public void whenSendingAStringThenIsAValidDominoTile(){

        String s = "1-1";
        assertTrue(App.stringIsATile(s));

    }


    @Test
    public void whenATileChainWithZeroMatchesStringThenItFindsOneLongestMatchingGroup(){


        String s = "1-1";
        assertEquals(App.longestMatchingGroup(s), 1);

    }

    @Test
    public void whenATileChainWith2TilesNotMatchingThenItFinds1AsLongestMatchingGroup(){
        String s = "1-2,1-2";
        assertEquals(App.longestMatchingGroup(s), 1);
    }

    @Test
    public void whenATileChainHave2TilesMatchingThenItFinds2AsLongestMatchingGroup(){
        String s = "1-2,2-1";
        assertEquals(App.longestMatchingGroup(s), 2);
    }

    @Test
    public void whenAChainHaveMoreThan2TilesButOnly2Matching(){
        String s = "1-2,2-1,3-3";
        assertEquals(App.longestMatchingGroup(s), 2);
    }

    @Test
    public void whenAChainHaveMoreThan2TilesAnd3Matching(){
        String s = "1-2,2-1,1-3";
        assertEquals(App.longestMatchingGroup(s), 3);
    }

    @Test
    public void testCaseInterview1(){
        String s = "1-1";
        assertEquals(App.longestMatchingGroup(s), 1);
    }

    @Test
    public void testCaseInterview2(){
        String s = "1-2,1-2";
        assertEquals(App.longestMatchingGroup(s), 1);
    }

    @Test
    public void testCaseInterview3(){
        String s = "3-2,2-1,1-4,4-4,5-4,4-2,2-1";
        assertEquals(App.longestMatchingGroup(s), 4);
    }

    @Test
    public void testCaseInterview4(){
        String s = "5-5,5-5,4-4,5-5,5-5,5-5,5-5,5-5,5-5,5-5";
        assertEquals(App.longestMatchingGroup(s), 7);
    }

    @Test
    public void testCaseInterview5(){
        String s = "1-1,3-5,5-5,5-4,4-2,1-3";
        assertEquals(App.longestMatchingGroup(s), 4);
    }

    @Test
    public void testCaseInterview6(){
        String s = "1-2,2-2,3-3,3-4,4-5,1-1,1-2";
        assertEquals(App.longestMatchingGroup(s), 3);
    }

    @Test
    public void testCaseInterview7(){
        String s = "1-1,1-1,1-1,2-2,2-2,3-3";
        assertEquals(App.longestMatchingGroup(s), 3);
    }

    @Test
    public void whenAskingForLongestRunWithOneTileShouldReturnOne(){

        Tile tile = new Tile(1,2);
        List<IChainElement> tiles = new ArrayList<>();
        tiles.add(tile);

       assertEquals(App.longestChain(tiles), 1);


    }

    @Test
    public void whenAskingForLongestRunWithTwoTilesButNotRunThenShouldReturnOne(){

        List<IChainElement> tiles = new ArrayList<>();
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,1));


       assertEquals(App.longestChain(tiles), 1);
    }

    @Test
    public void whenAskingForLongestRunWithTwoRepeatedTilesThenShouldReturnOne(){
        List<IChainElement> tiles = new ArrayList<>();
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));


        assertEquals(App.longestChain(tiles), 1);
    }

    @Test
    public void whenAskingForLongestRunWithSeveralRepeatedThenOneDifferentAndThenAgainSeveralRepeated(){
        List<IChainElement> tiles = new ArrayList<>();
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(5,6));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(1,2));
        tiles.add(new Tile(2,1));


       assertEquals(App.longestChain(tiles), 2);
    }

    @Test
    public void testCaseInterview8(){
        List<IChainElement> points = Arrays.asList(new Point(2, 9), new Point(23,
                94), new Point(23, 94), new Point(23, 94));
        assertEquals(App.longestChain(points), 3);
    }

    @Test
    public void whenDogListHaveConsecutiveNamesThenItShowsLongestRun(){
        List<IChainElement> dogs = Arrays.asList(new Dog("Ringo"), new Dog("Pancho"),
                new Dog("Pancho"), new Dog("Pancho"), new Dog("Pancho"), new Dog("Rufus"),
                new Dog("Ringo"), new Dog("Ringo"));
        assertEquals(App.longestChain(dogs), 4);
    }

}
