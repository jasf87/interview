package modusbox;

import modusbox.model.IChainElement;
import modusbox.model.Tile;

import java.util.*;

public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter a tile chain: ");
        String n = reader.next();
        reader.close();
        longestMatchingGroup(n);


    }

    public static boolean stringIsATile(String s) {
        return (s.matches("[0-6]-[0-6]"));
    }

    public static List<IChainElement> stringIsATileChain(String s) {
        List<String> tiles = Arrays.asList(s.split(","));
        boolean chain = true;
        List<IChainElement> tileList = new ArrayList<>();
        for (int i = 0; i < tiles.size() && chain ; i++){
            if (stringIsATile(tiles.get(i))) {
                tileList.add(getAsTile(tiles.get(i)));
            }
            else {
                return null;
            }

        }
        return tileList;
    }

    public static int longestMatchingGroup(String chain) {
        List<IChainElement> tiles = stringIsATileChain(chain);
        if (tiles != null){
            return longestChain(tiles);
        }
        else {
            System.out.println("Is not a valid tile chain");
            return 0;
        }

    }



    private static Tile getAsTile(String s) {
        String[] tileArray = s.split("-");
        return new Tile(Integer.parseInt(tileArray[0]), Integer.parseInt(tileArray[1]));
    }


    public static int longestChain(List<IChainElement> list) {
        int longest = 0;
        int currentLongest = 1;

        for (int i = 0; i < list.size(); i++) {
            IChainElement element = list.get(i);
            if (i + 1 < list.size() && element.matching(list.get(i + 1))) {
                currentLongest++;
            }
            else {
                currentLongest = 1;
            }

            longest = (longest < currentLongest) ? currentLongest : longest;

        }

        System.out.println(longest);
        return longest;

    }

}
