package modusbox.model;

public abstract class ChainElement implements IChainElement<ChainElement> {

    int firstElement;
    int secondElement;


    public ChainElement(int firstElement, int secondElement) {
        this.firstElement = firstElement;
        this.secondElement = secondElement;
    }
}
