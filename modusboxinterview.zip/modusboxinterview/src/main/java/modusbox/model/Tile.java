package modusbox.model;

public class Tile extends ChainElement{

    public Tile(int first, int second) {
        super(first, second);
    }

    @Override
    public boolean matching(ChainElement chainElement) {
        return secondElement == chainElement.firstElement;
    }
}
