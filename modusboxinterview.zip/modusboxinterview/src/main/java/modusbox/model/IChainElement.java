package modusbox.model;

public interface IChainElement<T> {

    boolean matching(T t);

}
