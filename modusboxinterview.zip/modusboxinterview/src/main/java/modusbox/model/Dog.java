package modusbox.model;

public class Dog implements IChainElement<Dog> {

    public Dog(String name) {
        this.name = name;
    }

    String name;


    @Override
    public boolean matching(Dog dog) {
        return name == dog.name;
    }
}
