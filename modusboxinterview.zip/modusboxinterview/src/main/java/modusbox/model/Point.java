package modusbox.model;


public class Point extends ChainElement {

    public Point(int x, int y) {
        super(x, y);
    }

    @Override
    public boolean matching(ChainElement t) {
        return firstElement == t.firstElement &&
                secondElement == t.secondElement;
    }
}
